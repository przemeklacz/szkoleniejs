((app) => {

	let ItemsController = app.controllers.ItemsController;
	new ItemsController();

})(App)